export type PlanColor = 'default' | 'green' | 'yellow' | 'gray' | 'red' | 'blue';

export interface Plan {
  id: string;
  title: string;
  date: string; // ISO string representing the date part
  startHour: number; // 7 to 22
  duration: number; // Number of hours (slots) it spans
  color: PlanColor;
}

export interface WeekMetadata {
  weekStarting: string; // ISO string
  color?: string; // Hex or CSS color
  note?: string;
  isImportant?: boolean;
}

export type Language = 'en' | 'vi';
export type Theme = 'light' | 'dark';

export interface AppSettings {
  language: Language;
  theme: Theme;
  musicEnabled: boolean;
  musicVolume: number;
}

export interface WeeklySchedule {
  weekStarting: string; // ISO string for Monday of that week
  plans: Plan[];
}

