/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as React from 'react';
import { 
  format, 
  startOfWeek, 
  addWeeks, 
  subWeeks, 
  isSameDay,
  isSameWeek 
} from 'date-fns';
import { Plan } from './types';
import { storage } from './lib/storage';
import { ScheduleGrid } from './components/ScheduleGrid';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import { 
  Calendar, 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  Trophy, 
  CheckCircle2,
  Settings,
  Moon,
  Sun,
  Volume2,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { translations } from './lib/i18n';
import { AppSettings, Language, Theme } from './types';

import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";

export default function App() {

  const [plans, setPlans] = React.useState<Plan[]>([]);
  const [weekMetas, setWeekMetas] = React.useState<Record<string, any>>({});
  const [currentTime, setCurrentTime] = React.useState(new Date());
  const [isSummaryOpen, setIsSummaryOpen] = React.useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = React.useState(false);
  
  const [settings, setSettings] = React.useState<AppSettings>(() => storage.getSettings());
  const t = (key: keyof typeof translations.en, params: Record<string, string> = {}) => {
    let text = translations[settings.language][key];
    Object.entries(params).forEach(([k, v]) => {
      text = text.replace(`{${k}}`, v);
    });
    return text;
  };

  const audioRef = React.useRef<HTMLAudioElement | null>(null);
  
  // Initialize to Monday of current week
  const [selectedWeekStart, setSelectedWeekStart] = React.useState(() => 
    startOfWeek(new Date(), { weekStartsOn: 1 })
  );

  React.useEffect(() => {
    setPlans(storage.getPlans());
    setWeekMetas(storage.getWeekMetas());
    
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Apply theme
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    return () => clearInterval(timer);
  }, [settings.theme]);

  React.useEffect(() => {
    if (settings.musicEnabled) {
      if (!audioRef.current) {
        audioRef.current = new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3');
        audioRef.current.loop = true;
      }
      audioRef.current.volume = settings.musicVolume;
      audioRef.current.play().catch(e => console.log('Music play blocked by browser', e));
    } else if (audioRef.current) {
      audioRef.current.pause();
    }
  }, [settings.musicEnabled, settings.musicVolume]);

  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    storage.saveSettings(newSettings);
  };

  const handleWeekMetaChange = (weekStart: string, color: string) => {
    storage.saveWeekMeta(weekStart, { color });
    setWeekMetas(storage.getWeekMetas());
    toast.success('Đã cập nhật trạng thái tuần');
  };

  const handleAddPlan = (plan: Plan) => {
    const updatedPlans = [...plans, plan];
    setPlans(updatedPlans);
    storage.savePlans(updatedPlans);
    toast.success('Đã thêm công việc');
  };

  const handleUpdatePlan = (updatedPlan: Plan) => {
    const updated = plans.map(p => p.id === updatedPlan.id ? updatedPlan : p);
    setPlans(updated);
    storage.savePlans(updated);
    toast.success('Đã cập nhật công việc');
  };

  const handleDeletePlan = (id: string) => {
    const updated = plans.filter(p => p.id !== id);
    setPlans(updated);
    storage.savePlans(updated);
    toast.info('Đã xóa công việc');
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    setSelectedWeekStart(prev => direction === 'prev' ? subWeeks(prev, 1) : addWeeks(prev, 1));
  };

  const goToToday = () => {
    setSelectedWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }));
  };

  // Generate week tabs
  const weekTabs = React.useMemo(() => {
    const today = startOfWeek(new Date(), { weekStartsOn: 1 });
    return Array.from({ length: 21 }, (_, i) => addWeeks(today, i - 10));
  }, []);

  const currentWeekPlans = React.useMemo(() => {
    return plans.filter(p => isSameWeek(new Date(p.date), selectedWeekStart, { weekStartsOn: 1 }));
  }, [plans, selectedWeekStart]);

  const completedPlansCount = currentWeekPlans.filter(p => p.color === 'green').length;
  const totalPlansCount = currentWeekPlans.length;

  return (
    <div className={cn(
      "min-h-screen flex flex-col transition-colors duration-300",
      settings.theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-[#F0F2F5] text-slate-900"
    )}>
      <header className={cn(
        "border-b border-slate-200 sticky top-0 z-50",
        settings.theme === 'dark' ? "bg-slate-900/80 backdrop-blur border-slate-800" : "bg-white/80 backdrop-blur"
      )}>
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-[#107C41] p-2 rounded-lg -rotate-3 hover:rotate-0 transition-transform">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className={cn(
                "text-xl font-black tracking-tight",
                settings.theme === 'dark' ? "text-white" : "text-[#107C41]"
              )}>{t('appName')}</h1>
              <p className={cn(
                "text-[10px] font-bold uppercase tracking-widest",
                settings.theme === 'dark' ? "text-slate-500" : "text-slate-400"
              )}>Professional Scheduler</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className={cn(
                "rounded-full",
                settings.theme === 'dark' ? "text-slate-300 hover:text-white" : "text-slate-600"
              )}
              onClick={() => setIsSettingsOpen(true)}
            >
              <Settings className="w-5 h-5" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className={cn(
                "hidden lg:flex gap-2",
                settings.theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-300" : "bg-slate-50 text-slate-600"
              )}
              onClick={() => setIsSummaryOpen(true)}
            >
              <Trophy className="w-4 h-4 text-yellow-600" />
              {t('summaryButton')}
            </Button>
            <div className={cn(
              "hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full border",
              settings.theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-200"
            )}>
              <Clock className="w-4 h-4 text-[#107C41]" />
              <span className="text-sm font-mono font-bold tabular-nums text-[#107C41]">
                {format(currentTime, 'HH:mm:ss')}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
        <div className="container mx-auto max-w-7xl">
          <div className="mb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h2 className={cn(
                "text-2xl font-black tracking-tight",
                settings.theme === 'dark' ? "text-white" : "text-slate-900"
              )}>
                {t('weekOf')} {format(selectedWeekStart, 'w')}
              </h2>
              <p className={cn(
                "text-sm font-medium",
                settings.theme === 'dark' ? "text-slate-400" : "text-slate-500"
              )}>
                {t('fromTo', { 
                  start: format(selectedWeekStart, 'd MMMM'),
                  end: format(addWeeks(selectedWeekStart, 1), 'd MMMM, yyyy')
                })}
              </p>
            </div>

            {completedPlansCount > 0 && (
              <div className={cn(
                "p-4 rounded-xl border shadow-sm flex items-center gap-4 animate-in fade-in slide-in-from-right-4",
                settings.theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div className="bg-yellow-500/10 p-2 rounded-full">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t('weeklyProgress')}</p>
                  <p className={cn(
                    "text-sm font-medium",
                    settings.theme === 'dark' ? "text-slate-200" : "text-slate-900"
                  )}>
                    {completedPlansCount} {t('tasksCompleted')}
                  </p>
                  <p className="text-[10px] text-yellow-500 font-bold italic mt-0.5">
                    "{t('keepGoing')}"
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className={cn(
            "shadow-2xl mb-8 overflow-hidden rounded-xl border transition-all",
            settings.theme === 'dark' ? "shadow-slate-900/50 border-slate-800" : "shadow-slate-200/50 border-slate-200"
          )}>
            <ScheduleGrid 
              currentWeekStart={selectedWeekStart}
              plans={plans}
              onAddPlan={handleAddPlan}
              onUpdatePlan={handleUpdatePlan}
              onDeletePlan={handleDeletePlan}
              language={settings.language}
              theme={settings.theme}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className={cn("border-none shadow-sm", settings.theme === 'dark' ? "bg-slate-900" : "bg-white")}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className={cn("font-bold", settings.theme === 'dark' ? "text-slate-300" : "text-slate-700")}>{t('weeklyProgress')}</h3>
                  <Badge className="bg-[#107C41] text-white hover:bg-[#107C41]">{completedPlansCount}/{totalPlansCount || 0}</Badge>
                </div>
                <div className={cn("w-full h-2 rounded-full overflow-hidden", settings.theme === 'dark' ? "bg-slate-800" : "bg-slate-100")}>
                  <div 
                    className="bg-[#107C41] h-full transition-all duration-1000" 
                    style={{ width: `${totalPlansCount > 0 ? (completedPlansCount / totalPlansCount) * 100 : 0}%` }}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2 border-none shadow-sm bg-[#107C41] text-white">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold mb-1">{t('stayFocused')}</h3>
                  <p className="text-white/70 text-sm">{t('planStepByStep')}</p>
                </div>
                <CheckCircle2 className="w-12 h-12 text-white/20" />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className={cn(
        "py-6 transition-colors border-t",
        settings.theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-1 hide-scrollbar">
              {weekTabs.map((weekStart, i) => {
                const isActive = isSameDay(weekStart, selectedWeekStart);
                const isTodayWeek = isSameDay(weekStart, startOfWeek(new Date(), { weekStartsOn: 1 }));
                const meta = weekMetas[weekStart.toISOString()];
                
                return (
                  <div key={i}>
                    <Popover>
                      <PopoverTrigger asChild>
                        <button
                          className={cn(
                            "px-4 py-1.5 text-xs font-medium border rounded-t-sm whitespace-nowrap transition-all relative group",
                            isActive 
                              ? "bg-[#107C41] text-white border-[#107C41] shadow-sm transform -translate-y-0.5" 
                              : (settings.theme === 'dark' ? "bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700" : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"),
                            isTodayWeek && !isActive && (settings.theme === 'dark' ? "border-b-2 border-b-[#107C41]" : "border-b-2 border-b-[#107C41]")
                          )}
                          onContextMenu={(e) => {
                            e.preventDefault();
                            setSelectedWeekStart(weekStart);
                          }}
                          onClick={() => setSelectedWeekStart(weekStart)}
                        >
                          {t('week')} {format(weekStart, 'w')}
                          {meta?.color && (
                            <div 
                              className="absolute bottom-0 left-0 right-0 h-1" 
                              style={{ backgroundColor: meta.color }}
                            />
                          )}
                        </button>
                      </PopoverTrigger>
                      <PopoverContent className={cn("w-40 p-2 border-none shadow-xl", settings.theme === 'dark' ? "bg-slate-800" : "bg-white")}>
                        <p className={cn("text-[10px] font-bold uppercase mb-2", settings.theme === 'dark' ? "text-slate-500" : "text-slate-400")}>{t('markWeek')}</p>
                        <div className="grid grid-cols-4 gap-1">
                          {['#FF0000', '#FFFF00', '#92D050', '#0070C0', '#7F7F7F', '#FFFFFF'].map(color => (
                            <button
                              key={color}
                              className="w-full aspect-square rounded border border-slate-200"
                              style={{ backgroundColor: color }}
                              onClick={() => handleWeekMetaChange(weekStart.toISOString(), color)}
                            />
                          ))}
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                );
              })}
            </div>
            
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-md">
                <Button variant="ghost" size="icon" onClick={() => navigateWeek('prev')} className="h-7 w-7">
                  <ChevronLeft className="w-3 h-3" />
                </Button>
                <Button variant="ghost" size="sm" onClick={goToToday} className="h-7 text-[10px] font-bold px-3">
                  {t('today')}
                </Button>
                <Button variant="ghost" size="icon" onClick={() => navigateWeek('next')} className="h-7 w-7">
                  <ChevronRight className="w-3 h-3" />
                </Button>
              </div>
              <p className={cn("text-xs font-medium", settings.theme === 'dark' ? "text-slate-500" : "text-slate-400")}>
                &copy; {format(currentTime, 'yyyy')} {t('appName')}
              </p>
            </div>
          </div>
        </div>
      </footer>

      <Toaster position="bottom-right" />

      <Dialog open={isSummaryOpen} onOpenChange={setIsSummaryOpen}>
        <DialogContent className={cn(
          "max-w-4xl max-h-[85vh] overflow-hidden flex flex-col border-none p-0",
          settings.theme === 'dark' ? "bg-slate-900" : "bg-[#F0F2F5]"
        )}>
          <DialogHeader className={cn(
            "p-6 border-b",
            settings.theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200"
          )}>
            <DialogTitle className={cn(
              "text-xl font-black flex items-center gap-3",
              settings.theme === 'dark' ? "text-white" : "text-slate-900"
            )}>
              <div className="bg-yellow-500/20 p-2 rounded-lg">
                <Trophy className="w-5 h-5 text-yellow-500" />
              </div>
              {t('summaryYear', { year: format(currentTime, 'yyyy') })}
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex-1 overflow-auto p-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {Array.from({ length: 52 }, (_, i) => {
                const yearStart = startOfWeek(new Date(new Date().getFullYear(), 0, 1), { weekStartsOn: 1 });
                const weekStart = addWeeks(yearStart, i);
                const weekIso = weekStart.toISOString();
                const meta = weekMetas[weekIso];
                const weekPlans = plans.filter(p => isSameWeek(new Date(p.date), weekStart, { weekStartsOn: 1 }));
                const completed = weekPlans.filter(p => p.color === 'green').length;
                const total = weekPlans.length;
                const isCurrent = isSameWeek(new Date(), weekStart, { weekStartsOn: 1 });

                return (
                  <div 
                    key={i}
                    onClick={() => {
                      setSelectedWeekStart(weekStart);
                      setIsSummaryOpen(false);
                    }}
                    className={cn(
                      "rounded-xl p-3 border-2 transition-all cursor-pointer hover:shadow-md hover:scale-[1.02]",
                      "group relative overflow-hidden",
                      settings.theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-transparent",
                      isCurrent && "border-[#107C41]"
                    )}
                  >
                    {meta?.color && (
                      <div className="absolute top-0 right-0 w-8 h-8 -mr-4 -mt-4 rotate-45" style={{ backgroundColor: meta.color }} />
                    )}
                    <div className="text-[10px] font-bold text-slate-400 uppercase mb-1">{t('week')} {i + 1}</div>
                    <div className={cn("text-xs font-bold mb-2", settings.theme === 'dark' ? "text-slate-300" : "text-slate-700")}>
                      {format(weekStart, 'd/M')} - {format(addWeeks(weekStart, 1), 'd/M')}
                    </div>
                    {total > 0 && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] items-center">
                          <span className="text-slate-500">{completed}/{total}</span>
                          <span className="text-[#107C41] font-bold">{Math.round((completed/total)*100)}%</span>
                        </div>
                        <div className={cn("w-full h-1 rounded-full overflow-hidden", settings.theme === 'dark' ? "bg-slate-700" : "bg-slate-100")}>
                          <div 
                            className="bg-[#107C41] h-full transition-all" 
                            style={{ width: `${(completed/total)*100}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
        <DialogContent className={cn(
          "max-w-md border-none sm:rounded-2xl",
          settings.theme === 'dark' ? "bg-slate-900" : "bg-white"
        )}>
          <DialogHeader>
            <DialogTitle className={cn(
              "text-xl font-black",
              settings.theme === 'dark' ? "text-white" : "text-[#107C41]"
            )}>{t('settings')}</DialogTitle>
            <DialogDescription className="text-slate-500">
              Customize your experience with the planner.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className={cn("font-bold", settings.theme === 'dark' ? "text-slate-300" : "text-slate-700")}>
                  {t('language')}
                </Label>
                <p className="text-xs text-slate-500">Choose your preferred language.</p>
              </div>
              <Select 
                value={settings.language} 
                onValueChange={(val: Language) => handleUpdateSettings({ language: val })}
              >
                <SelectTrigger className="w-32 bg-slate-50 border-slate-200 dark:bg-slate-800 dark:border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="vi">Tiếng Việt</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className={cn("font-bold", settings.theme === 'dark' ? "text-slate-300" : "text-slate-700")}>
                  {t('theme')}
                </Label>
                <p className="text-xs text-slate-500">Switch between light and dark modes.</p>
              </div>
              <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                <Button 
                  variant={settings.theme === 'light' ? 'secondary' : 'ghost'} 
                  size="sm" 
                  className="h-8 w-8 p-0"
                  onClick={() => handleUpdateSettings({ theme: 'light' })}
                >
                  <Sun className="h-4 w-4" />
                </Button>
                <Button 
                  variant={settings.theme === 'dark' ? 'secondary' : 'ghost'} 
                  size="sm" 
                  className="h-8 w-8 p-0"
                  onClick={() => handleUpdateSettings({ theme: 'dark' })}
                >
                  <Moon className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-indigo-500/10 p-2 rounded-lg">
                    <Volume2 className="w-4 h-4 text-indigo-500" />
                  </div>
                  <div className="space-y-0.5">
                    <Label className={cn("font-bold", settings.theme === 'dark' ? "text-slate-300" : "text-slate-700")}>
                      {t('music')}
                    </Label>
                    <p className="text-xs text-slate-500">Background chill music for focus.</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.musicEnabled} 
                  onCheckedChange={(val) => handleUpdateSettings({ musicEnabled: val })}
                />
              </div>

              {settings.musicEnabled && (
                <div className="px-2">
                  <Slider 
                    value={[settings.musicVolume * 100]} 
                    max={100} 
                    step={1}
                    onValueChange={(val) => {
                      const value = Array.isArray(val) ? val[0] : val;
                      handleUpdateSettings({ musicVolume: value / 100 });
                    }}
                    className="cursor-pointer"
                  />
                </div>
              )}
            </div>
          </div>
          <div className="p-4 border-t border-slate-100 dark:border-slate-800 text-center">
            <p className={cn(
              "text-[10px] font-black uppercase tracking-[0.2em]",
              settings.theme === 'dark' ? "text-slate-600" : "text-slate-300"
            )}>
              Created by <span className="text-[#107C41]">ThanhBicycle</span>
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}


